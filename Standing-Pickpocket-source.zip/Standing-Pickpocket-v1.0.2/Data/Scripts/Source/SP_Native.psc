Scriptname SP_Native Hidden Native
Int Function GetKey() Global Native
Function SetKey(Int keyCode) Global Native


Bool Function GetDisableVanilla() Global Native
Function SetDisableVanilla(Bool disabled) Global Native


Float Function GetDistanceMultiplier() Global Native
Function SetDistanceMultiplier(Float multiplier) Global Native


Bool Function IsDistanceOverridden() Global Native

Bool Function GetFollowerInventory() Global Native
Function SetFollowerInventory(Bool enabled) Global Native
Bool Function GetHorseInventory() Global Native
Function SetHorseInventory(Bool enabled) Global Native
