# Standing Pickpocket v1.0.2

Adds a separate pickpocket hotkey for standing or sneaking. Aim at a living NPC and press **G**, or set your own key under **MCM > Standing Pickpocket**.

## Pickpocket distance
MCM's **Pickpocket distance multiplier** ranges from **0.1 to 1.0**, default/max **1.0**. At 1.0 the engine's crosshair targeting preserves vanilla reach. Lower values add a native actor-distance check against the live ActivatePickLength:Interface setting multiplied by the chosen value (180-unit fallback if unavailable). This affects the separate key, ordinary sneaking pickpocket activation and its HUD prompt. Talking retains its usual reach. Outside reduced pickpocket reach, the NPC prompt returns to ordinary interaction. Settings save across restarts.

## Behavior
- Native SKSE input handling and menu opening: no Papyrus hotkey polling or pickpocket action scripts.
- Routes the hotkey through the normal NPC activation chain using a scoped target request, allowing installed activation hooks and engine pickpocket rules to run. Does not change persistent sneak state or stance animations, item success chances, perks, or crime handling.
- Optional **Disable vanilla pickpocket** toggle (off by default): normal Activate uses talk/interaction while sneaking, and the HUD uses the corresponding vanilla localized prompt. The separate key still pickpockets. Followers retain normal interaction; optional companion inventory access is described below.
- Living, pickpocketable targets only, within the configured pickpocket reach. No opening through a paused menu, dialogue, console, or disabled Activate controls.
- Fires once per key press, not repeatedly while held. Supports SKSE keyboard, mouse and controller key codes.
- MCM also saves the vanilla-pickpocket toggle across restarts. Native NPC activation/HUD hooks implement the setting; Papyrus only presents its menu controls.
- MCM supports changing, unbinding, conflict confirmation and restoring G. Changes save to Data/SKSE/Plugins/StandingPickpocket.ini.
- Duplicate/renamed plugin DLL copies terminate startup with an explanation.

## Integrations and requirements
- **Skyrim Special Edition / Anniversary Edition, Steam:** one DLL built with CommonLibSSE-NG's SE/AE runtime accessors and Address Library relocation IDs. Intended for SE 1.5.97 and supported AE runtimes. Actual game validation on SE and AE remains required; compilation does not prove each runtime works.
- **SKSE64:** use the version matching your game executable.
- **Address Library for SKSE Plugins:** use the version matching your game runtime.
- **SkyUI:** required for MCM. The small Papyrus script handles menu settings only.
- **Mod Organizer 2 / Vortex:** install the release ZIP normally and enable StandingPickpocket.esp.

No save, game folder, or mod-manager installation is modified by the build. With the toggle enabled, a scoped native check temporarily masks the single sneak-state bit inside living-NPC activation/text calls and restores it on exit; it does not issue sneak inputs or update animations. Corpses, containers and non-player activators retain their original path. A new quest registers the MCM on an existing or new save; allow the usual SkyUI registration time after loading.

## Installation
Install the release ZIP in your mod manager, enable StandingPickpocket.esp, and launch through SKSE64. The archive's root is the Data folder contents. Do not install the source workspace as a mod.

## Build
Run Build-StandingPickpocket.bat. Build-Native.ps1 expects an MSVC 19.51 x64 toolchain and Windows SDK, supplied through -ToolchainRoot or the local tools/msvc/unpack layout. The CommonLib prebuilt bundle requires the matching MSVC compiler family/version. Vendor sources and pinned dependencies are included in the workspace.

Caprica compiles only SP_MCM.psc and SP_Native.psc using compile-only API headers. Never install those headers or compile/replace SkyUI, Quest, or Form scripts. tools/make_plugin.py generates the MCM quest ESP and SEQ; tools/package.py validates and packages the deliverables. Python 3 is required for these helpers.

## Validation
Native and Papyrus build logs are in logs/. Structural checks validate the ESP quest/SEQ and required install files. Live menu opening, MCM registration, pickpocket consequences and both game runtimes need in-game testing.

## Additions we wanted to implement
None beyond the requested native hotkey and MCM binding.

Windows must have a current Microsoft Visual C++ v14 x64 runtime. The DLL was built with MSVC 19.51. Windows DLL loading and exported-symbol checks passed on this machine; SKSE/game testing has not been run.








DAK integration was removed in v1.4.0. Existing saved DAK mode settings are retired automatically; the saved hotkey, vanilla toggle and distance preference are preserved.


## Native distance API
The installed StandingPickpocketAPI.h declares version 1. At SKSE kPostLoad or later resolve StandingPickpocket_RequestAPI with GetProcAddress from StandingPickpocket.dll, then request version 1. Check missing module/export/null API before use. Use a stable non-null owner token (for example the address of a static variable) to SetDistanceOverride(token, multiplier). Valid values are finite 0.1�1.0; the first owner claims control, only that owner can update/release, competing requests return false. ReleaseDistanceOverride(token) restores the user's saved value. Overrides do not write the INI and must be reapplied each game launch. Effective distance governs both key/vanilla pickpocket and HUD. MCM disables the slider and explains external control when the page opens; refresh the page after a live ownership change. The token is never dereferenced and no mod callbacks run in AI/UI hooks.
Existing saved keybinds are preserved; new installations and MCM reset default use G. Escape during rebinding unbinds the key.

## Companion inventories and current pickpocket rules
MCM has separate Open follower inventory and Open horse inventory toggles, both off by default. When enabled, the hotkey requests the engine Actor.OpenInventory native for the existing actor inventory for current player teammates and owned mounts. It creates no container, items, storage quest or ownership changes. Custom horse saddlebag containers are not automatically discovered; they require their own adapter. Other mounts are excluded. Normal Activate is unchanged by this option.
For ordinary NPCs, the hotkey now uses ActivateRef instead of directly opening the pickpocket menu, with a scoped target request that bypasses this mod's Disable vanilla option for the requested NPC. Installed activation and engine rules can run. It does not recalculate chances or reset game settings. Mods that depend on animation, physical sneak entry events or their own UI still require individual compatibility testing; no universal compatibility is claimed.

 v1.0.1 uses a one-shot native VM dispatch to the existing Actor.OpenInventory function for companion access; no custom action script or polling is added. The engine performs menu setup rather than opening kNPCMode directly.

 v1.0.1 removes the shared last-ridden-mount virtual call. Horse shortcut eligibility now requires direct player ownership. Inventory hotkey checkpoints are flushed to StandingPickpocket.log for crash diagnosis.

## Release version and light plugin
The release numbering restarts at v1.0.1. StandingPickpocket.esp is ESL-flagged (light) and retains its filename and local quest ID 0x800; no FormID compaction was needed. The native DLL and archive version are also 1.0.1. Conversion of an existing full-plugin save has not been tested; keep a pre-upgrade save backup. Existing crash-repair changes are included, but the G-key crash fix is still unconfirmed in game.

 v1.0.1 migrates the old combined inventory preference to both toggles when no separate preferences exist. Horses use only the horse toggle, including mounts marked as teammates. User confirmed G-key inventory access works with the preceding build.

## v1.0.2 stance fix
The G hotkey no longer sets a fake player sneak flag. It calls reference activation with a thread-local target request; this mod's NPC handler opens the engine pickpocket menu using the real player stance. Genuine sneaking is preserved. Upstream reference hooks and pickpocket menu/chance/crime hooks still apply; NPC-activation overrides that require taking over the final menu route need explicit compatibility. The old global-flag scope could expose artificial stealth to HUD/followers/other mods even if restored immediately. Already-stuck saves may need one manual enter/exit of sneak after upgrading; the mod does not guess whether existing stealth is genuine.
The install ZIP contains only gameplay ESP/DLL/PEX/INI, SEQ and LICENSE. API headers and development documents remain in the workspace.
